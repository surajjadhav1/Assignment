package bank;
//default, public, private
public class Finance{
    //private, public, protected, default
	public static double interest(double a, double r, int n){

		return (a * r * n) / 100;
	}
}
