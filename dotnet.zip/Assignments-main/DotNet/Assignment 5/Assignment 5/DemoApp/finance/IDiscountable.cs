namespace finance;

interface IDiscountable {
	double Discountable(double emi);	
}
