namespace series;

interface IResetable
{
    void Reset();
}