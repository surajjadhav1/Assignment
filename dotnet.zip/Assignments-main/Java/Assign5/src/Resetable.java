package series;

interface Resetable {
	
	void reset();
}

