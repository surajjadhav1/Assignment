package finance;

interface Discountable {
	double discountable(double emi);	
}

